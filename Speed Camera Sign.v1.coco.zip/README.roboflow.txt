
Speed Camera Sign - v1 2021-02-20 7:04pm
==============================

This dataset was exported via roboflow.ai on February 20, 2021 at 7:05 PM GMT

It includes 18 images.
Signs are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


